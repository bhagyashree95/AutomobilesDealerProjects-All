var app = angular.module('myApp', ["ngRoute"]);
app.config(['$routeProvider','$locationProvider',function($routeProvider,$locationProvider) {
  $locationProvider.hashPrefix('');
    $routeProvider
    .when("/Home", {
        templateUrl : "pages/home.html",
        controller : "myCtrl1"
      })
      .when("/dealer", {
          templateUrl : "pages/dealer.html",
          controller : "myCtrl"
        })
        .when("/aboutUs", {
            templateUrl : "pages/aboutUs.html",
              controller : "myCtrl2"
            })
            .when("/tata", {
                templateUrl : "pages/tata.html",
                controller : "tataController"
                })
                .when("/maruthi", {
                    templateUrl : "pages/maruthi.html",
                    controller : "mzCtrl"
                    })
                    .when("/Tigor", {
                        templateUrl : "pages/tigor.html",
                        controller : "tigorCtrl"
                        })
                        .when("/Indigo", {
                            templateUrl : "pages/indigo.html",
                            controller : "indigoCtrl"
                            })
                            .when("/Zest", {
                                templateUrl : "pages/zest.html",
                                controller : "zestCtrl"
                                })
                                .when("/Nano", {
                                    templateUrl : "pages/nano.html",
                                    controller : "nanoCtrl"
                                    })
                                    .when("/Sumo", {
                                        templateUrl : "pages/sumo.html",
                                        controller : "sumoCtrl"
                                        })
                                        .when("/Hexa", {
                                            templateUrl : "pages/hexa.html",
                                            controller : "hexaCtrl"
                                            })
                                            .when("/Swift", {
                                                templateUrl : "pages/swift.html",
                                                controller : "swiftCtrl"
                                                })
                                                .when("/Alto", {
                                                    templateUrl : "pages/alto.html",
                                                    controller : "altoCtrl"
                                                    })
                                                    .when("/Celerio", {
                                                        templateUrl : "pages/celerio.html",
                                                        controller : "celerioCtrl"
                                                        })
                                                        .when("/Omni", {
                                                            templateUrl : "pages/omni.html",
                                                            controller : "omniCtrl"
                                                            })
                                                            .when("/Ertiga", {
                                                                templateUrl : "pages/ertiga.html",
                                                                controller : "ertigaCtrl"
                                                                })
                                                                .when("/Brezza", {
                                                                    templateUrl : "pages/brezza.html",
                                                                    controller : "brezzaCtrl"
                                                                    })
            .when("/ContactUS", {
                templateUrl : "pages/contact.html",
                  controller : "myCtrl3"
                })
    .otherwise({
      redirectTo: "/dealer"
    });
}]);
app.controller('myCtrl',function($scope,$location) {
    $scope.myFunc = function() {

        if($scope.userName == "yogi" && $scope.passwd =="123")
      $location.path('/Home');
        else {
          alert("fail");
        }
    };
});
app.controller('myCtrl1',function($scope,$location) {
});
app.controller('myCtrl2',function($scope,$location) {
  $location.path('/aboutUs');
  $scope.carList = [{id:'1',autologo:'Images/tata.png',autoName:'TATA',viewMore:''},
                    {id:'2',autologo:'Images/mz.jpg',autoName:'MARUTHI',viewMore:''}]
  $scope.viewMore=function(id)
  {
    if(id == 1)
    {
    $location.path("/tata");
  }
  else if(id == 2)
  {
  $location.path("/maruthi");
}
  else {
    location.path("/dealer");
  }
  }

});
app.controller('myCtrl3',function($scope,$location) {
  $location.path('/ContactUS');
});
app.controller('tataController',function($scope,$location) {
});
app.controller('tigorCtrl',function($scope,$location) {
$location.path('/Tigor');
  $scope.buyNow=function(){
    alert("Congratulations.....!")
  }
});
app.controller('indigoCtrl',function($scope,$location) {
$location.path('/Indigo');
  $scope.buyNow=function(){
    alert("Congratulations.....!")
  }
});
app.controller('zestCtrl',function($scope,$location) {
$location.path('/Zest');
  $scope.buyNow=function(){
    alert("Congratulations.....!")
  }
});
app.controller('nanoCtrl',function($scope,$location) {
$location.path('/Nano');
  $scope.buyNow=function(){
    alert("Congratulations.....!")
  }
});
app.controller('sumoCtrl',function($scope,$location) {
$location.path('/Sumo');
  $scope.buyNow=function(){
    alert("Congratulations.....!")
  }
});
app.controller('hexaCtrl',function($scope,$location) {
$location.path('/Hexa');
  $scope.buyNow=function(){
    alert("Congratulations.....!")
  }
});

app.controller('swiftCtrl',function($scope,$location) {
$location.path('/Swift');
  $scope.buyNow=function(){
    alert("Congratulations.....!")
  }
});
app.controller('altoCtrl',function($scope,$location) {
$location.path('/Alto');
  $scope.buyNow=function(){
    alert("Congratulations.....!")
  }
});
app.controller('celerioCtrl',function($scope,$location) {
$location.path('/Celerio');
  $scope.buyNow=function(){
    alert("Congratulations.....!")
  }
});
app.controller('omniCtrl',function($scope,$location) {
$location.path('/Omni');
  $scope.buyNow=function(){
    alert("Congratulations.....!")
  }
});
app.controller('ertigaCtrl',function($scope,$location) {
$location.path('/Ertiga');
  $scope.buyNow=function(){
    alert("Congratulations.....!")
  }
});
app.controller('brezzaCtrl',function($scope,$location) {
$location.path('/Brezza');
  $scope.buyNow=function(){
    alert("Congratulations.....!")
  }
});
