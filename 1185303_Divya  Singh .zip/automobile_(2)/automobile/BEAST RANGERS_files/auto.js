

  var app =angular.module('carApp',['ngRoute']);

app.config(['$routeProvider','$locationProvider',function ($routeProvider, $locationProvider) {
    $locationProvider.hashPrefix('');
    $routeProvider
	.when("/login", {
            templateUrl: "login.html",
             controller: "carCtrl"  
}).when("/automobile", {
            templateUrl: "automobile.html",
            controller: "carCtrl" 
}).when("/home", {
            templateUrl: "home.html",
            controller: "carCtrl" 
        })
		.when("/carhome", {
            templateUrl: "home.html",
            controller: "carCtrl" 
        })
		.when("/lout", {
            templateUrl: "login.html",
            controller: "carCtrl" 
        }) 
		.when("/Audi", {
            templateUrl: "audi.html",
            controller: "carCtrl" 
        }) 
		.when("/Ford", {
            templateUrl: "Ford.html",
            controller: "carCtrl" 
        }) 
		.when("/Jaguar", {
            templateUrl: "Jaguar.html",
            controller: "carCtrl" 
        }) 
		.when("/BMW", {
            templateUrl: "BMW.html",
            controller: "carCtrl" 
        }) 
		.when("/Audi-A3-sedan", {
            templateUrl: "audia3.html",
            controller: "carCtrl" 
        })
          .when("/Audi-A4", {
            templateUrl: "audia4.html"
           /*  controller: "carCtrl"  */	
		  })		   
		.when("/Audi-S3", {
            templateUrl: "audis3.html"	
		  })
		  .when("/Ford1", {
            templateUrl: "fordeco.html",
            controller: "carCtrl" 
        })
		.when("/Ford2", {
            templateUrl: "fordfigo.html",
            controller: "carCtrl" 
        })
		.when("/Ford3", {
            templateUrl: "mustang.html",
            controller: "carCtrl" 
        })
		.when("/jagf", {
            templateUrl: "jaguarfpace.html",
            controller: "carCtrl" 
        })
		.when("/jagxe", {
            templateUrl: "jaguarxe.html",
            controller: "carCtrl" 
        })
		.when("/jagxf", {
            templateUrl: "jaguarxf.html",
        })
		.when("/bmw3", {
            templateUrl: "bmw3.html",
            controller: "carCtrl" 
        })
		.when("/bmw1", {
            templateUrl: "bmw1.html",
            controller: "carCtrl" 
        })
		.when("/bmwx1", {
            templateUrl: "bmwx1.html",
            controller: "carCtrl" 
        })
		.when("/back", {
            templateUrl: "bmw.html",
            controller: "carCtrl" 
        })
		.when("/back1", {
            templateUrl: "audi.html",
            controller: "carCtrl" 
        })
		.when("/back2", {
            templateUrl: "jaguar.html",
            controller: "carCtrl" 
        })
		.when("/back3", {
            templateUrl: "ford.html",
            controller: "carCtrl" 
        })
		.otherwise({
            redirectTo: '/login'
        });
}]);
		
		
		app.controller('carCtrl',function($scope, $location){
			
					$scope.validate=function()
	{	
if(($scope.uname=="admin")&&($scope.psw=="admin"))
		{
			$location.path('/home');
		}
		
		else
		{
			alert("Please enter valid Username and Password");
		}
	}
	
			
			
			
			
			
		});
		
		app.directive('carousel', function($timeout) {
   return {
      restrict: 'E',
      scope: {
        links: '=' 
      },
      templateUrl: 'carousel.html',
      link: function(scope, element) {
        $timeout(function() {
          $('.carousel-indicators li',element).first().addClass('active');
          $('.carousel-inner .item',element).first().addClass('active');
        });
      }
   }
});
		
		

	
