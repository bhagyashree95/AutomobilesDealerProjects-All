 var mainApp = angular.module("mainApp", ['ngRoute']);
		mainApp.factory('resolveservice', function($location,$rootScope) {
			return{
				check:function(){
								if(!$rootScope.loggedIn){
									$location.path('/login');
								}
							}
					} 
		});
         mainApp.config(['$routeProvider','$locationProvider',function ($routeProvider, $locationProvider) {
			 $locationProvider.hashPrefix('');
			 
			  
            $routeProvider
			. when('/login', {
               templateUrl: 'login.html',
               controller: 'LoginController'
            })
			. when('/register', {
               templateUrl: 'register.html',
               controller: 'RegisterController'
            })
			. when('/forgotpassword', {
               templateUrl: 'forgotpassword.html',
               controller: 'ForgotpasswordController'
            })
			. when('/home', {
               templateUrl: 'home.html',
               controller: 'HomeController',
			    resolve: {
           		 	message: function(resolveservice){
                 			return resolveservice.check();
			           			}  	}		  
            })
			. when('/tatamotors', {
               templateUrl: 'tatamotors.html',
               controller: 'TatamotorsController',
			    resolve: {
           		 	message: function(resolveservice){
                 			return resolveservice.check();
			           			}  	}	
					})
						. when('/jaguarcars', {
						   templateUrl: 'jaguarcars.html',
						    controller: 'JaguarcarsController',
						    resolve: {
			           		 	message: function(resolveservice){
			                 			return resolveservice.check();
						           			}  	}								
						})
						. when('/tataaria', {
						   templateUrl: 'tataaria.html',
						    controller: 'TataariaController',
						    resolve: {
			           		 	message: function(resolveservice){
			                 			return resolveservice.check();
						           			}  	}	
						   })
						. when('/tatanano', {
						   templateUrl: 'tatanano.html',
						    controller: 'TatananoController',
						    resolve: {
			           		 	message: function(resolveservice){
			                 			return resolveservice.check();
						           			}  	}	
						})
						. when('/tatasumo', {
						   templateUrl: 'tatasumo.html',
						    controller: 'TatasumoController',
						    resolve: {
			           		 	message: function(resolveservice){
			                 			return resolveservice.check();
						           			}  	}	
						})
			. when('/mahindra', {
               templateUrl: 'mahindra .html',
               controller: 'MahindraController',
			    resolve: {
           		 	message: function(resolveservice){
                 			return resolveservice.check();
			           			}  	}	
				})
						. when('/mahindrathar', {
						   templateUrl: 'mahindrathar.html',
						    controller: 'MahindratharController',
						    resolve: {
			           		 	message: function(resolveservice){
			                 			return resolveservice.check();
						           			}  	}	
						})
								. when('/mahindratharfullimage', {
									templateUrl: 'mahindratharfullimage.html',
									controller: 'MahindratharController',
								    resolve: {
					           		 	message: function(resolveservice){
					                 			return resolveservice.check();
								           			}  	}	
								})
						. when('/mahindraxylo', {
						   templateUrl: 'mahindraxylo.html',
						    controller: 'MahindraxyloController',
						    resolve: {
			           		 	message: function(resolveservice){
			                 			return resolveservice.check();
						           			}  	}	
						})
								. when('/mahindraxylofullimage', {
										templateUrl: 'mahindraxylofullimage.html',
									    resolve: {
						           		 	message: function(resolveservice){
						                 			return resolveservice.check();
									           			}  	}	
								})
						. when('/mahindraquanto', {
						   templateUrl: 'mahindraquanto.html',
						    controller: 'MahindraquantoController',
						    resolve: {
			           		 	message: function(resolveservice){
			                 			return resolveservice.check();
						           			}  	}	
						})
								. when('/mahindraquantofullimage', {
										templateUrl: 'mahindraquantofullimage.html',
									    resolve: {
						           		 	message: function(resolveservice){
						                 			return resolveservice.check();
									           			}  	}	
								})
						. when('/mahindrascorpio', {
						   templateUrl: 'mahindrascorpio.html',
						    controller: 'MahindrascorpioController',
						    resolve: {
			           		 	message: function(resolveservice){
			                 			return resolveservice.check();
						           			}  	}	
						})
								. when('/mahindrascrpiofullimage', {
										templateUrl: 'mahindrascrpiofullimage.html',
									    resolve: {
						           		 	message: function(resolveservice){
						                 			return resolveservice.check();
									           			}  	}	
								})	
			. when('/success', {
               templateUrl: 'success.html',
			    controller: 'SuccessController',
			    resolve: {
           		 	message: function(resolveservice){
                 			return resolveservice.check();
			           			}  	}			
            })			
            .otherwise({
               redirectTo: '/login'
			   
            });			
         }]);
		 
		 mainApp.controller('LoginController', function($scope,$interval,$location,$rootScope) {
            $scope.message = "Login ";
				$interval(function () {
				$scope.theTime = new Date().toLocaleTimeString();
				}, 1000);
			$scope.login = function() {
/* 					var username = $scope.username;
					var password = $scope.password; */
					if ($scope.username == "123" && $scope.password == "123") {
						$rootScope.loggedIn=true;
						$location.path("/home" );
						} 
					else {
						alert('invalid username and password');
						}
				};
		   });
		 mainApp.controller('RegisterController', function($scope,$location) {
            $scope.message = "Registration Page ";
			$scope.register = function() {
					if ($scope.password == $scope.confirm) {
						$location.path("/login" );
						} 
					else {
						alert('Mismatch password');
						}
				};
		   });
		 mainApp.controller('ForgotpasswordController', function($scope,$location) {
            $scope.message = "Forgot Password?";
 			$scope.forgotpassword = function() {
					if ($scope.email=="rselva@gmail.com") {
						if($scope.password == $scope.confirm){
							$location.path("/login" );
						}
						else{
							alert('Mismatch password');
						}
						
						} 
					else {
						alert('Please enter correct email');
						}
				}; 
		   });
		   
		 mainApp.controller('HomeController', function($scope,$location,$timeout) {
			   $scope.message = "Welcome to Our Shopping Website";
				  $timeout(function () {
					  $scope.message = "AUTOMOBILE";
				  }, 3000);
			$scope.automobile=[
                {id:"1",
				name: "Tata Motors",
				image:"image/tatamotors.jpg"
				},
				
				{id:"2",
					name: "Mahindra & Mahindra Limited (M&M)",
			        image:"image/Mahindra.jpg"     
                }
            ] 
			$scope.tatamotorview = function(taskid) {
				if(taskid==1){
				$location.path("/tatamotors" );
				}
				else{
				$location.path("/mahindra" );
				}
			};
			
			   });
		 mainApp.controller('TatamotorsController', function($scope,$interval,$location) {
            $scope.message = "Tata Motors Product";
			$interval(function(){
			$scope.theTime = new Date().toLocaleTimeString();	
			},1000);
			$scope.myInterval=1000;
			$scope.tataproduct=[
                {id:"1",
				name: "Jaguar Cars",
				image1:"image/jaguar/jaguar.jpg",
				description:"Jaguar is the luxury vehicle brand of Jaguar Land Rover"
				},
				
				{id:"2",
				name: "Tata Aria",
				image1:"image/tataaria/tataaria.jpg",
				description:"Tata Aria was also a series of concept cars introduced by Tata Motors"
			              
                },
				{id:"3",
				name: "Tata Nano",
				image1:"image/tatanano/Tata_Nano.jpg",
				description:"Tata Nano is a city car manufactured by Tata Motors"
			              
                } ,
				{id:"4",
				name: "Tata Sumo",
				image1:"image/tatasumo/tata-sumo.jpg",
				description:"Tata Sumo is a multi-utility vehicle produced by India's largest automotive company"
			              
                } 
				
            ] 
				$scope.tataviewdetails = function(taskid) {
				if(taskid==1){
					//alert("success");
				$location.path('/jaguarcars' );
				}
				else if(taskid==2){
					$location.path('/tataaria' );
				}
				else if(taskid==3){
					$location.path('/tatanano' );
				}
				else{
				$location.path("/tatasumo" );
				}
			};

			   });
									 mainApp.controller('JaguarcarsController', function($scope,$location,$window,$rootScope) {
										$scope.message = "Jaguar Cars ";
										$scope.myInterval=1000;
						 			 	$scope.jaguarcar=[
											{
											image1:"image/jaguar/jaguar.jpg",
											image2:"image/jaguar/Jaguar Cars1.jpg",
											image3:"image/jaguar/jagura car2.jpg"											
											}											
										] 
											$scope.tatabuy = function(purseitem) {
												buyUser =$window.confirm('Are you sure you want to buy the product?');
												 if(buyUser){
												 alert('Successfuly ordered your Product............ ');
												 $rootScope.purseitem=purseitem;
												 $location.path('/success' );
												}
											}
									   });
									 mainApp.controller('TataariaController', function($scope,$location,$window,$rootScope) {
										$scope.message = "Tata Aria ";
										$scope.myInterval=1000;
						 			 	$scope.tataariacar=[
											{
											image1:"image/tataaria/tataaria1.jpg",
											image2:"image/tataaria/tataaria2.jpg",
											image3:"image/tataaria/tataaria3.jpg"											
											}											
										] 
											$scope.tatabuy = function(purseitem) {
												buyUser =$window.confirm('Are you sure you want to buy the product?');
												 if(buyUser){
												 alert('Successfuly ordered your Product............ ');
												 $rootScope.purseitem=purseitem;
												 $location.path('/success' );
												}
											}
									   });
										mainApp.controller('TatananoController', function($scope,$location,$window,$rootScope) {
										$scope.message = "Tata Nano ";
										$scope.myInterval=1000;
						 			 	$scope.tatananocar=[
											{
											image1:"image/tatanano/tatanano1.jpg",
											image2:"image/tatanano/tatanano2.jpg",
											image3:"image/tatanano/tatanano3.jpg"											
											}											
										] 
											$scope.tatabuy = function(purseitem) {
												buyUser =$window.confirm('Are you sure you want to buy the product?');
												 if(buyUser){
												 alert('Successfuly ordered your Product............ ');
												 $rootScope.purseitem=purseitem;
												 $location.path('/success' );
												}
											}
									   });
									   mainApp.controller('TatasumoController', function($scope,$location,$window,$rootScope) {
										$scope.message = "Tata Sumo ";
										$scope.myInterval=1000;
						 			 	$scope.tatasumocar=[
											{
											image1:"image/tatasumo/tatasumo1.jpg",
											image2:"image/tatasumo/tatasumo2.jpg",
											image3:"image/tatasumo/tatasumo3.jpg"											
											}											
										] 
											$scope.tatabuy = function(purseitem) {
												buyUser =$window.confirm('Are you sure you want to buy the product?');
												 if(buyUser){
												 alert('Successfuly ordered your Product............ ');
												 $rootScope.purseitem=purseitem;
												 $location.path('/success' );
												}
											}
									   });
		 mainApp.controller('MahindraController', function($scope,$location) {
            $scope.message = "Mahindra & Mahindra Limited (M&M) Product";
			$scope.mahindraproduct=[
                {id:"1",
				name: "Mahindra Thar",
				image1:"image/mahindrathar/Mahindra-THAR.jpg",
				description:"The Mahindra Thar is a compact and mid-size four-wheel drive off-road and sport utility vehicle"
				},
				
				{id:"2",
				name: "Mahindra Xylo",
				image1:"image/mahindraxylo/Mahindra-Xylo.jpg",
				description:"The Mahindra Xylo is a CUV, designed and manufactured by Mahindra & Mahindra."
			              
                },
				{id:"3",
				name: "Mahindra Quanto",
				image1:"image/Mahindra quanto/Mahindra quanto.jpg",
				description:"The Mahindra Quanto is a Mini sport utility vehicle automobile designed and manufactured by the Indian M&M Limited."
			              
                },
				{id:"4",
				name: "Mahindra Scorpio",
				image1:"image/Mahindrascorpio/Mahindra-Scorpio.jpg",
				description:"The Mahindra Scorpio is a four-wheel drive SUV manufactured by Mahindra & Mahindra Limited (M&M),"
			              
                }
				
            ] 
				$scope.tataviewdetails = function(taskid) {
				if(taskid==1){
					//alert("success");
				$location.path("/mahindrathar" );
				}
				else if(taskid==2){
					$location.path("/mahindraxylo" );
				}
				else if(taskid==3){
					$location.path("/mahindraquanto" );
				}
				else{
				$location.path("/mahindrascorpio" );
				}
			};
			   });
			   							mainApp.controller('MahindratharController', function($scope,$location,$window,$rootScope) {
										$scope.message = "Mahindra Thar ";
										$scope.changePicture = function() {
											$location.path('/mahindratharfullimage' ); 
										} 
											$scope.tatabuy = function(purseitem) {
												 buyUser =$window.confirm('Are you sure you want to buy the product?');
												 if(buyUser){
												 alert('Successfuly ordered your Product............ ');
												 $rootScope.purseitem=purseitem;
												 $location.path('/success' );
												}
											}
									   });
									   mainApp.controller('MahindraxyloController', function($scope,$location,$window,$rootScope) {
										$scope.message = "Mahindra Xylo ";
										$scope.changePicture = function() {
											$location.path('/mahindraxylofullimage' ); 
										}
											$scope.tatabuy = function(purseitem) {
												 buyUser =$window.confirm('Are you sure you want to buy the product?');
												 if(buyUser){
												 alert('Successfuly ordered your Product............ ');
												 $rootScope.purseitem=purseitem;
												 $location.path('/success' );
												}
											}
									   });
									   mainApp.controller('MahindraquantoController', function($scope,$location,$window,$rootScope) {
										$scope.message = "Mahindra Quanto ";
										$scope.changePicture = function() {
											$location.path('/mahindraquantofullimage' ); 
										}
											$scope.tatabuy = function(purseitem) {
												 buyUser =$window.confirm('Are you sure you want to buy the product?');
												 if(buyUser){
												 alert('Successfuly ordered your Product............ ');
												 $rootScope.purseitem=purseitem;
												 $location.path('/success' );
												}
											}
									   });
									   mainApp.controller('MahindrascorpioController', function($scope,$location,$window,$rootScope) {
										$scope.message = "Mahindra Scorpio ";
										$scope.changePicture = function() {
											$location.path('/mahindrascrpiofullimage' ); 
										}
											$scope.tatabuy = function(purseitem) {
												 buyUser =$window.confirm('Are you sure you want to buy the product?');
												 if(buyUser){
												 alert('Successfuly ordered your Product............ ');
												 $rootScope.purseitem=purseitem;
												 $location.path('/success' );
												}
											}
									   });
			   
			mainApp.controller('SuccessController', function($scope,$rootScope) {
				$scope.product=$rootScope.purseitem;
           // $scope.success = "Successfuly ordered your Product............ ";
		   });