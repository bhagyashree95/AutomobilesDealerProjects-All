
var app = angular.module('myApp',["ngRoute"]);
app.config(['$routeProvider','$locationProvider',function ($routeProvider, $locationProvider) {
    $locationProvider.hashPrefix('');
    $routeProvider
        .when("/Home", {
            templateUrl: "home.html",
            controller: "controller"
        })
        .when("/login", {
            templateUrl: "login.html",
            controller: "logincontroller"
        })
        .when("/Automobile_lists",{
        templateUrl:"Automobile_lists.html",
        controller:"automobile_listscontroller"
          })
        .when("/Aboutus",{
        templateUrl:"Aboutus.html",
        controller:"aboutcontroller"
          })
          .when("/Tata", {
              templateUrl: "Tata.html",

          })
          .when("/Ford", {
              templateUrl: "Ford.html",

          })
          .when("/BMW", {
              templateUrl: "Bmw.html",

        })
        .when("/Audi", {
            templateUrl: "Audi.html",

      })
      .when("/Benz", {
          templateUrl: "Benz.html",

    })
    .when("/BMW_oneseries", {
        templateUrl: "pages/BMW_cars/BMW_oneseries.html",

  })
  .when("/BMW-3GT", {
      templateUrl: "pages/BMW_cars/BMW-3GT.html",

})
.when("/BMW-5-series", {
    templateUrl: "pages/BMW_cars/BMW-5-series.html",

})
.when("/BMW-X3", {
    templateUrl: "pages/BMW_cars/BMW-X3.html",

})
.when("/BMW_Z4", {
    templateUrl: "pages/BMW_cars/BMW_Z4.html",

})
.when("/fordaspire", {
    templateUrl: "pages/Ford_cars/fordaspire.html",

})
.when("/fordecosport", {
    templateUrl: "pages/Ford_cars/fordecosport.html",

})
.when("/fordendeavour", {
    templateUrl: "pages/Ford_cars/fordendeavour.html",

})
.when("/fordfigo", {
    templateUrl: "pages/Ford_cars/fordfigo.html",

})
.when("/fordmustang", {
    templateUrl: "pages/Ford_cars/fordmustang.html",

})

.when("/tatatiago", {
    templateUrl: "pages/TATA_cars/tatatiago.html",

})
.when("/tatabolt", {
    templateUrl: "pages/TATA_cars/tatabolt.html",

})
.when("/tataindigo", {
    templateUrl: "pages/TATA_cars/tataindigo.html",

})
.when("/tatabolero", {
    templateUrl: "pages/TATA_cars/tatabolero.html",

})
        .otherwise({
            redirectTo: '/login'
        });


}]);

app.controller('logincontroller', function($scope,$location){
 $scope.loginfunction= function(){
if($scope.login.email=="satish@gmail.com" && $scope.login.password=="satish")
$location.path('/Home');
else {
  alert("Invalid Credentials");
};
};
});
app.controller('controller', function($scope,$location){
  $scope.message="Welcome to Global Automobile Dealer"
  });
  app.controller('aboutcontroller',function($scope, $location){
 $location.path('/Aboutus');

  });
  app.controller('automobile_listscontroller', function($scope,$location){
  $location.path('/Automobile_lists');

  });
  app.controller('BMWcontroller', function($scope,$location){
    $scope.buynow=function(){
  $location.path('/BMW_oneseries');
  }
  $scope.buynow1=function(){
$location.path("/BMW-3GT");
}
$scope.buynow2=function(){
$location.path('/BMW-5-series');
}
$scope.buynow3=function(){
$location.path('/BMW-X3');
}
$scope.buynow4=function(){
$location.path('/BMW_Z4');
}

  });

  app.controller('Fordcontroller', function($scope,$location){
    $scope.buynow=function(){
  $location.path('/fordaspire');
  }
  $scope.buynow1=function(){
$location.path("/fordecosport");
}
$scope.buynow2=function(){
$location.path('/fordendeavour');
}
$scope.buynow3=function(){
$location.path('/fordfigo');
}
$scope.buynow4=function(){
$location.path('/fordmustang');
}

  });



  app.controller('tablecontroller',function($scope,$location){
   $scope.AutoList=[{id:"1",tataimage:"images/tatalogo1.jpg",ProductName:"Tata Motors",Viewmore:""},
   {id:"2",tataimage:"images/fordlogo.png",ProductName:"Ford",Viewmore:""},
 {id:"3",tataimage:"images/bmwlogo1.jpg",ProductName:"BMW",Viewmore:""},
{id:"4",tataimage:"images/audilogo.png",ProductName:"Audi",Viewmore:""}];
  $scope.somefunction=function(id){
    if(id==1){
  $location.path("/Tata");
}
else if(id==2){
  $location.path("/Ford");

}
else if (id==3) {
  $location.path("/BMW");
}
else if (id==4) {
  $location.path("/Audi");
}
else if (id==5) {
  $location.path("/Benz");
}
  else{
  $location.path( '/login');
}
}
});

app.controller('tatabuyController',function($scope,$location){

$scope.buyfunction=function(){

$location.path('/tatatiago');

}
$scope.buyfunction2=function(){

$location.path('/tatabolt');

}
$scope.buyfunction3=function(){

$location.path('/tataindigo');

}
$scope.buyfunction4=function(){

$location.path('/tatabolero');

}

});
app.controller('alertController',function($scope,$window){
  $scope.alertfunction=function(){

  $window.confirm("Are you sure to buy this car ??");
  if (confirm) {
    alert('Congratulation!!!!!!')
  }
  }

});
