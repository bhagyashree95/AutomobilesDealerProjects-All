var app = angular.module("myApp", ['ngRoute']);
         app.config(['$routeProvider','$locationProvider',function ($routeProvider, $locationProvider) {
$locationProvider.hashPrefix('');
            $routeProvider
       .when('/login', {
                 templateUrl: 'routing/Login.html',

            })
            .when('/home', {
               templateUrl: 'routing/Home.html'

            })
            .when('/allCars', {
               templateUrl: 'routing/allCars.html',
               controller: 'allcarsCtrl'
            })
            .when('/cardetails', {
               templateUrl: 'routing/cardetails.html',
               controller: 'allcarsCtrl'
            })
            .when('/Volkswagen Polo', {
               templateUrl: 'routing/Volkswagen Polo.html'
            })
            .when('/volkswagen-tiguan', {
               templateUrl: 'routing/volkswagen-tiguan.html'
            })
            .when('/Jaguar F-Type', {
               templateUrl: 'routing/Jaguar F-Type.html'

            })
            .when('/support', {
               templateUrl: 'routing/support.html'
            })
            .when('/payment', {
               templateUrl: 'routing/payment.html'
            })
            .when('/audi', {
               templateUrl: 'routing/audi.html'
            })
            .when('/main', {
              templateUrl: '/main.html',
               controller: 'mainController'
            })
           .otherwise({
               redirectTo: '/login'
            });
         }]);

         app.run(function ($rootScope,$location) {
            $rootScope.login = function () {
        				var username = $rootScope.username;
        				var password = $rootScope.password;
        				if (username == "admin" && password == "admin") {
        					$location.path("/allCars");
                  $rootScope.loginSuccess="true"
                  $rootScope.logout="false"
        				}
        				else {
        					alert('invalid username and password');
        				}
        			};
              $rootScope.logout = function () {$rootScope.logout="true"};
        });




    app.value("detailArray", {
      detail : [{imgurl1:'https://www.jaguar.in/Images/X152_18MY_045_00064_tcm163-318921_desktop_1366x768.jpg?v=28',imgurl2:'https://jaguar.ssl.cdn.sdlmedia.com/636180200898230568VX.jpg?v=7#desktop_1366x769',imgurl3:'https://jaguar.ssl.cdn.sdlmedia.com/636180200914636175IJ.jpg?v=5#desktop_1366x650',imgurl4:'https://jaguar.ssl.cdn.sdlmedia.com/636180200880418454CE.jpg?v=6#desktop_1366x769', modelName:'Jaguar F-Type', Power:'542bhp', Engine:'5.0 v8 petrol',Fueleconomy:'25 - 26 mpg',price:'2.08Cr',brand:'Jaguar'}]
});
   app.value("myArray", {
    imgList : [{imgurl:'https://auto.ndtvimg.com/car-images/medium/volkswagen/tiguan/volkswagen-tiguan.jpg?v=20', modelName:'Volkswagen Tiguan', details:'/volkswagen-tiguan', Type:'SUV',price:'38.31',brand:'volkswagen',color:'blue'},
                      {imgurl:'https://auto.ndtvimg.com/car-images/gallery/volkswagen/polo-gti/exterior/polo_gti.jpg', modelName:'Volkswagen Polo', details:'/Volkswagen Polo', Type:'hatch back',price:'23.42',brand:'volkswagen',color:'white'},
                      {imgurl:'http://www.thaicarlover.com/wp-content/uploads/2012/10/2014-Jaguar-F-Type-1.jpg', modelName:'Jaguar F-Type', details:'/Jaguar F-Type', Type:'Convertables',price:'125',brand:'jaguar',color:'red'},
                    {imgurl:'https://auto.ndtvimg.com/car-images/medium/lexus/es/lexus-es.jpg?v=4', modelName:'lexus-es', details:'/lexus-es', Type:'Sedan',price:'59.46',brand:'lexus',color:'grey'},
                    {imgurl:'http://st.motortrend.com/uploads/sites/10/2015/11/2016-audi-a8-l-42-sedan-angular-front.png', modelName:'Audi A8', details:'/audi', Type:'Sedan',price:'755',brand:'audi',color:'black'}]
                });
  app.controller('allcarsCtrl', function($scope,$location,myArray) {
      $scope.allcars = myArray.imgList;
      $scope.detail= [{imgurl1:'https://www.jaguar.in/Images/X152_18MY_045_00064_tcm163-318921_desktop_1366x768.jpg?v=28',imgurl2:'https://jaguar.ssl.cdn.sdlmedia.com/636180200898230568VX.jpg?v=7#desktop_1366x769',imgurl3:'https://jaguar.ssl.cdn.sdlmedia.com/636180200914636175IJ.jpg?v=5#desktop_1366x650',imgurl4:'https://jaguar.ssl.cdn.sdlmedia.com/636180200880418454CE.jpg?v=6#desktop_1366x769', modelName:'Jaguar F-Type', Power:'542bhp', Engine:'5.0 v8 petrol',Fueleconomy:'25 - 26 mpg',price:'2.08Cr',brand:'Jaguar'}]
      $scope.myFunction = function() {
         var txt;
   var r = confirm("Proceeding to payment...!!");
   if (r == true) {
       alert("congratulations....!!!");
   } else {
       $location.path("/cardetails");
   }
       }
      $scope.viewByMe = function(x) {
        $scope.myviewBy = x;
    }
    $scope.viewdet = function(x) {
      $location.path("/cardetails");
  }

  }
);
