var app =angular.module('myApp',['ngRoute']);
app.config(['$routeProvider','$locationProvider',function ($routeProvider, $locationProvider) {
    $locationProvider.hashPrefix('');
    $routeProvider
    .when("/DealerApp", {
            templateUrl: "DealerApp.html",
            controller: "DealerController" 
}).when("/DealerHome", {
            templateUrl: "DealerHome.html",
            controller: "DealerController" 
        })
		
		.when("/Introduction", {
            templateUrl: "DealerIntro.html",
          
        })
		.when("/Hatchbacks", {
            templateUrl: "Hatchbacks.html",
          
        })
		.when("/Tata", {
            templateUrl: "Tata.html",
          
        })
		.when("/Toyota", {
            templateUrl: "Toyota.html",
          
        })
		.when("/Home", {
            templateUrl: "DealerHome.html",
          
        })
		.when("/Zen", {
            templateUrl: "Zen.html",
			controller: "PurchaseController"
          
        })
		.when("/Success", {
            templateUrl: "Success.html",
          
        })
		.when("/UtilityVehicles", {
            templateUrl: "UtilityVehicles.html",
          
        })
		.when("/Tiago", {
            templateUrl: "Tiagocar.html",
			controller: "PurchaseController"
            
        })
		.when("/Toyotaetios", {
            templateUrl: "Toyotaetios.html",
			controller: "PurchaseController"
            
        })
		.when("/Zest", {
            templateUrl: "Zest.html",
			controller: "PurchaseController"
            
        })
		.when("/Indigo", {
            templateUrl: "Indigo.html",
			controller: "PurchaseController"
            
        })
		.when("/Hexa", {
            templateUrl: "Hexa.html",
			controller: "PurchaseController"
            
        })
		.when("/Safari", {
            templateUrl: "Safari.html",
			controller: "PurchaseController"
            
        })
		
		
		.otherwise({
            redirectTo: '/DealerApp'
        });
}]);
app.controller('DealerController',function($scope,$location,$window)
{
	
	$scope.validate=function()
	{	
if(($scope.uname=="admin")&&($scope.pwd=="admin"))
		{ 
			$location.path('/DealerHome');
		}
		
		else
		{
			$window.alert("Please enter valid Username and Password");
		}
	}; 
	$scope.logout=function()
	{
		$location.path('/DealerApp');
	};
			
			
			
			
});
		 	 app.controller('PurchaseController',function($scope,$window,$location)
			{
				$scope.buynow=function()
				{
					  /* if( $window.confirm("Do you want to Purchase?"));
					 {  
                     $scope.result = "Congratulation! you have Purchase Tiago.....";
					 } */
					  if ($window.confirm("Do you want to Purchase?")) {
                    $location.path('/Success');
                } else {
                   $location.path('/DealerHome');
                }
					 
                     
				};
			});  
			
			/* app.controller('searchController',function($scope)
			{ */
				
			
			